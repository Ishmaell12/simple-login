package com.jms.loginactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static EditText userName;
    private static EditText userPassword;
    private static Button login_btn;
    private static TextView attempt_counter;

    private String Username = "Admin";
    private String Password = "123456789";

    boolean isValid = false;
    private int counter = 5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = findViewById(R.id.log);
        userPassword = findViewById(R.id.pass);
        login_btn = findViewById(R.id.btnClick);
        attempt_counter = findViewById(R.id.attemptInfo);

        login_btn.setOnClickListener(new View.OnClickListener(){
            @Override

            public void onClick(View v){

                String inputName = userName.getText().toString();
                String inputPassword = userPassword.getText().toString();

                if(inputName.isEmpty() || inputPassword.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please fill in the required information", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    isValid = validate(inputName, inputPassword);

                    if (!isValid){

                        counter--;

                        Toast.makeText(MainActivity.this, "Incorrect Fill In", Toast.LENGTH_SHORT).show();

                        attempt_counter.setText("Attempts: "+ counter);

                        if(counter == 0){
                            login_btn.setEnabled(false);
                        }

                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "User and Password correct", Toast.LENGTH_SHORT).show();

                        //Add new Activity
                        Intent intent = new Intent(MainActivity.this, User.class);
                        startActivity(intent);
                    }

                }
            }
        });


    }
    private boolean validate(String name, String password){

        if (name.equals(Username) && password.equals(Password)){
            return true;
        }

        return false;
    }
}